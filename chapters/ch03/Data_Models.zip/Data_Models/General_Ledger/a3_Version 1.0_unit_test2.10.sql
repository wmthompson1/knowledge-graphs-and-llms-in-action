/**********************************************************************************************
Description:
Sample:
Date      Modified By      Change Description
---------- ------------------ ------------------------------------------------------------
**********************************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET DEADLOCK_PRIORITY LOW
IF OBJECT_ID('tempdb..#Results') IS NOT NULL DROP TABLE #Results
IF OBJECT_ID('tempdb..#RawDemoData') IS NOT NULL DROP TABLE #RawDemoData

CREATE TABLE #RawDemoData (
    row_no      INT IDENTITY(1,1),
    customer_id INT,
    dist_no     INT,
    raw_value   INT
);

INSERT INTO #RawDemoData (customer_id, dist_no, raw_value)
VALUES
    -- First emission group
    (123, 1, 100),
    (123, 2, 100),
    (123, 2, 25),

    -- Second emission group
    (123, 3, 100),
    (123, 3, 25),
    (123, 3, 35),

    -- Third emission group
    (123, 4, 100),
    (123, 4, 25),
    (123, 4, 35),
    (123, 4, 10),

    -- Customer 456
    -- First emission group
    (456, 1, 200),

    -- Second emission group
    (456, 2, 200),
    (456, 2, 50),

    -- Third emission group
    (456, 3, 200),
    (456, 3, 50),
    (456, 3, 75);

select *
from #RawDemoData;

