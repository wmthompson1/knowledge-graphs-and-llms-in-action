prompt:
create Explainer for Terminology and ontology. Create 2-3 pages of content based on field
discriptions. The explainer will be placed in the knowledge loop folder, /@Documentation\my-mrp-kb\customer-orders
 - use existing code base to augment field descriptions.

Field Descriptions for Query,Descriptions,Comment
Customer_Order,,Alias of CUSTOMER_ORDER.ID
BASE_ID,FROM WORK_ORDER wo,
Buyer_ID,See Schema Guide,
ORDER_DATE,FROM CUSTOMER_ORDER,
DUE_DATE,From WO.DESIRED_WANT_DATE,Local Term
CHANGES,FROM HISTORY_DATA WHERE ACTION = 'UPDATE',Integer - the number of times the work order was updated.
SHIPPED_DATE,The actual shipped date.,Compare and contrast with Desired ship date. MAX(SHIPPED_DATE) SHIPPER table
Changes_Detail,FROM HISTORY_DATA TABLE - Audit Of History,


```sql
/**
Data Model Customer Order
Terms
Sub-Folder: Custom and Unlinked


**/

DECLARE @StartDate DATE = '2026-04-01', @EndDate DATE = '2026-04-30'
--BASE TABLE TO ADD CANGES

; WITH CTE_CO_WO AS (
    SELECT distinct CO.ID AS 'Customer_Order', WO.BASE_ID, P.BUYER_USER_ID AS 'Buyer_ID', 
    CO.ORDER_DATE, WO.DESIRED_WANT_DATE AS 'DUE_DATE', WO.WO_PK
    FROM CUSTOMER_ORDER CO WITH (NOLOCK)
    INNER JOIN DEMAND_SUPPLY_LINK DSL WITH (NOLOCK) ON CO.ID = DSL.DEMAND_BASE_ID 
    INNER JOIN (SELECT BASE_ID, LOT_ID, SPLIT_ID, SUB_ID, 'W~'+BASE_ID+'~'+LOT_ID+'~'+SPLIT_ID+'~'+SUB_ID AS 'WO_PK',
                PART_ID, DESIRED_WANT_DATE FROM WORK_ORDER WITH (NOLOCK) WHERE TYPE = 'W' AND SUB_ID = 0
    ) AS WO ON DSL.SUPPLY_BASE_ID = WO.BASE_ID AND DSL.SUPPLY_LOT_ID = WO.LOT_ID
        AND DSL.SUPPLY_SPLIT_ID = WO.SPLIT_ID AND DSL.SUPPLY_SUB_ID = WO.SUB_ID
    INNER JOIN PART P ON WO.PART_ID = P.ID
    WHERE CO.CUSTOMER_ID = 'BOE609'
)

SELECT A.Customer_Order, A.BASE_ID, 
    CASE 
        WHEN A.Buyer_ID like '609-%' THEN LEFT(A.Buyer_ID, 3) 
        WHEN A.Buyer_ID like 'BOE-%' THEN LEFT(A.Buyer_ID, 3) 
        ELSE CONVERT( VARCHAR(2), LEFT(A.Buyer_ID, 2) ) 
    END AS 'Buyer_ID', A.ORDER_DATE, A.DUE_DATE,
    IIF(HC.NUM_CHANG IS NULL, 0, HC.NUM_CHANG) AS 'CHANGES', S.SHIPPED_DATE,
    SUBSTRING(HC2.Changes_Detail, 1, LEN(HC2.Changes_Detail)-2) AS 'Changes_Detail'
FROM CTE_CO_WO A
LEFT JOIN (SELECT COUNT(PRIMARY_KEY) AS 'NUM_CHANG', PRIMARY_KEY FROM HISTORY_DATA WITH (NOLOCK)
    WHERE ACTION = 'UPDATE' AND NEW_VALUE IS NOT NULL AND TBL_NAME = 'WORK_ORDER' AND COL_NAME = 'DESIRED_WANT_DATE'
    GROUP BY PRIMARY_KEY
) HC ON A.WO_PK = HC.PRIMARY_KEY
LEFT JOIN (
    SELECT PRIMARY_KEY, 
        STRING_AGG(CONVERT (NVARCHAR (MAX), LEFT(SUBSTRING(OLD_VALUE, 1, LEN(NEW_VALUE)-2), 12)+', '), CHAR(13)) AS 'Changes_Detail' 
    FROM HISTORY_DATA WHERE ACTION = 'UPDATE'  AND TBL_NAME = 'WORK_ORDER' AND COL_NAME = 'DESIRED_WANT_DATE' 
    GROUP BY PRIMARY_KEY
) HC2 ON A.WO_PK = HC2.PRIMARY_KEY
INNER JOIN (
    SELECT MAX(SHIPPED_DATE) AS 'SHIPPED_DATE', CUST_ORDER_ID 
    FROM SHIPPER WITH (NOLOCK) GROUP BY CUST_ORDER_ID
) S ON A.Customer_Order = S.CUST_ORDER_ID
WHERE S.SHIPPED_DATE >= @StartDate and S.SHIPPED_DATE <= @EndDate
```
